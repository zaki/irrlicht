========================================================================
       WIN32-ANWENDUNG : IrrFontTool
========================================================================


Diese IrrFontTool-Anwendung hat der Anwendungs-Assistent f�r Sie erstellt.  

Diese Datei enth�lt eine Zusammenfassung dessen, was Sie in jeder der Dateien
finden, die Ihre IrrFontTool-Anwendung bilden.

IrrFontTool.cpp
    Dieses ist die Hauptquellcodedatei der Anwendung.

IrrFontTool.dsp
    Diese Datei (Projektdatei) enth�lt Informationen auf Projektebene und wird zur
    Erstellung eines einzelnen Projekts oder Teilprojekts verwendet. Andere Benutzer k�nnen
    die Projektdatei (.dsp) gemeinsam nutzen, sollten aber die Makefiles lokal exportieren.
	

/////////////////////////////////////////////////////////////////////////////
Weitere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden zum Erstellen einer vorkompilierten Header-Datei (PCH) namens
    IrrFontTool.pch und einer vorkompilierten Typdatei namens StdAfx.obj verwendet.


/////////////////////////////////////////////////////////////////////////////
Weitere Hinweise:

Der Anwendungs-Assistent verwendet "ZU ERLEDIGEN:", um Bereiche des Quellcodes zu
kennzeichnen, die Sie hinzuf�gen oder anpassen sollten.


/////////////////////////////////////////////////////////////////////////////
